// ignore_for_file: prefer_single_quotes, lines_longer_than_80_chars final
Map<String, dynamic> environment = {
  "appConfig": "lib/config/config_ar.json",
  "serverConfig": {
    "url": "https://acwady.com",
    "type": "woo",
    "consumerKey": "ck_cab7ff30fa9575a10a89dc0bc30d301ec3ffc079",
    "consumerSecret": "cs_773c1bab3273f56e4987af1de2ff0d2b9053aff2"
  },
  "multiSiteConfigs": [
    {
      "configFolder": "us_store",
      "serverConfig": {
        "url": "https://acwady.com",
        "type": "woo",
        "consumerKey": "ck_cab7ff30fa9575a10a89dc0bc30d301ec3ffc079",
        "consumerSecret": "cs_773c1bab3273f56e4987af1de2ff0d2b9053aff2",
      },
      "name": "الكويت(الرسمي)",
      "icon":
      "assets/images/country/ar.png",
      "languageCode": "ar",
      "currencyCode": "KWD",
      "countryCode": "KW",
      "myFatoorahApiKey": "KW-key",
      "myFatoorahAccountCountryCode": "KW",
    },
    {
      "configFolder": "vi_store",
      "serverConfig": {
        "url": "https://abdeel.me",
        "type": "woo",
        "consumerKey": "ck_cab7ff30fa9575a10a89dc0bc30d301ec3ffc079",
        "consumerSecret": "cs_773c1bab3273f56e4987af1de2ff0d2b9053aff2",
      },
      "name": "(test env)",
      "icon":
      "assets/images/country/sa.png",
      "languageCode": "ar",
      "currencyCode": "KWD",
      "countryCode": "KW",
      "myFatoorahApiKey": "KW-key",
      "myFatoorahAccountCountryCode": "KW",
    },
  ],

  "defaultDarkTheme": false,
  "enableRemoteConfigFirebase": false,
  "enableFirebaseAnalytics": true,
  "loginSMSConstants": {
    "dialCodeDefault": "+965",
    "nameDefault": "الكويت",
    "countryCodeDefault": "KW"
  },
  "phoneNumberConfig": {
    "dialCodeDefault": "+965",
    "customCountryList": ["KW"],
    "formatInput": false,
    "selectorFlagAsPrefixIcon": true,
    "enable": true,
    "countryCodeDefault": "KW",
    "showCountryFlag": true,
    "selectorType": "BOTTOM_SHEET",
    "useInternationalFormat": true
  },
  "appRatingConfig": {
    "minLaunches": 10,
    "showOnOpen": false,
    "remindDays": 7,
    "appStoreIdentifier": "6478245402",
    "minDays": 7,
    "remindLaunches": 10,
    "googlePlayIdentifier": "com.acwady.app"
  },
  "advanceConfig": {
    "DefaultLanguage": "ar",
    "DetailedBlogLayout": "halfSizeImageType",
    "EnablePointReward": false,
    "hideOutOfStock": false,
    "HideEmptyTags": true,
    "HideEmptyCategories": true,
    "EnableRating": true,
    "hideEmptyProductListRating": true,
    "EnableCart": true,
    "ShowBottomCornerCart": false,
    "EnableSkuSearch": true,
    "showStockStatus": true,
    "GridCount": 3,
    "isCaching": false,
    "kIsResizeImage": false,
    "httpCache": false,
    "Currencies": [
      {
        "symbol": "د,ك",
        "decimalDigits": 2,
        "symbolBeforeTheNumber": true,
        "currency": "KWD",
        "currencyCode": "KWD",
      },
      {
        "symbol": "ر,س",
        "decimalDigits": 2,
        "symbolBeforeTheNumber": true,
        "currency": "SAR",
        "currencyCode": "SAR",
      },
    ],
    "DefaultStoreViewCode": "",
    "EnableAttributesConfigurableProduct": ["color", "size"],
    "isMultiLanguages": true,
    "EnableApprovedReview": false,
    "EnableSyncCartFromWebsite": false,
    "EnableSyncCartToWebsite": false,
    "EnableFirebase": true,
    "RatioProductImage": 1.2,
    "EnableCouponCode": true,
    "ShowCouponList": false,
    "ShowAllCoupons": false,
    "ShowExpiredCoupons": false,
    "AlwaysShowTabBar": true,
    "PrivacyPoliciesPageUrlOrId": "https://acwady.com/privacy-policy",
    "SupportPageUrl": "https://support.inspireui.com/",
    "DownloadPageUrl": "https://mstore.io/#download",
    "SocialConnectUrl": [
      {
        "name": "Facebook",
        "icon": "assets/icons/logins/facebook.png",
        "url": "https://www.facebook.com/inspireui"
      },
      {
        "name": "Instagram",
        "icon": "assets/icons/logins/instagram.png",
        "url": "https://www.instagram.com/inspireui9/"
      }
    ],
    "AutoDetectLanguage": false,
    "QueryRadiusDistance": 10,
    "MinQueryRadiusDistance": 1,
    "MaxQueryRadiusDistance": 10,
    "EnableWooCommerceWholesalePrices": false,
    "IsRequiredSiteSelection": true,
    "EnableDeliveryDateOnCheckout": false,
    "EnableNewSMSLogin": false,
    "EnableBottomAddToCart": true,
    "inAppWebView": false,
    "EnableWOOCSCurrencySwitcher": false,
    "enableProductBackdrop": true,
    "categoryImageMenu": true,
    "EnableDigitsMobileLogin": true,
    "EnableDigitsMobileFirebase": false,
    "EnableDigitsMobileWhatsApp": false,
    "WebViewScript":
        "document.getElementById('header').style.display = 'none';document.getElementBy" +
            "Id('footer').style.display = 'none';",
    "versionCheck": {
      "iosId": "com.acwady.app",
      "enable": true,
      "iOSAppStoreCountry": "",
      "androidPlayStoreCountry": "",
      "androidId": "com.acwady.app"
    },
    "AjaxSearchURL": "",
    "AlwaysClearWebViewCache": false,
    "AlwaysClearWebViewCookie": false,
    "AlwaysRefreshBlog": false,
    "OrderNotesWithPrivateNote": false,
    "OrderNotesLinkSupport": false,
    "inAppUpdateForAndroid": {"enable": true, "typeUpdate": "flexible"},
    "categoryConfig": {"enableLargeCategories": false, "deepLevel": 3},
    "pinnedProductTags": [],
    "TimeShowToastMessage": 1500,
    "cartCheckoutButtonLocation": "centerFloat",
    "showRequestNotification": true,
    "DefaultCurrency": {
      "symbol": "KD",
      "smallestUnitRate": 1,
      "countryCode": "KW",
      "decimalDigits": 3,
      "symbolBeforeTheNumber": true,
      "currency": "Kuwaiti Dinar",
      "currencyCode": "KWD"
    },
    "gdpr": {
      "confirmCaptcha": "PERMANENTLY DELETE",
      "showPrivacyPolicyFirstTime": false,
      "showDeleteAccount": false
    },
    "PrivacyPoliciesPageUrl": "https://acwady.com/privacy-policyy/",
    "EnableAttributesLabelConfigurableProduct": ["color", "size"]
  },
  "defaultDrawer": {
    "logo": "assets/images/logo.png",
    "items": [
      {"show": true, "type": "home"},
      {"show": true, "type": "blog"},
      {"show": true, "type": "categories"},
      {"show": true, "type": "cart"},
      {"show": true, "type": "profile"},
      {"show": true, "type": "login"},
      {"show": true, "type": "category"}
    ]
  },
  "defaultSettings": [
    "biometrics",
    "products",
    "wallet",
    "chat",
    "wishlist",
    "notifications",
    "language",
    "currencies",
    "darkTheme",
    "order",
    "point",
    "rating",
    "privacy",
    "about"
  ],
  "loginSetting": {
    "facebookAppId": "430258564493822",
    "requirePhoneNumberWhenRegister": true,
    "showAppleLogin": false,
    "showGoogleLogin": false,
    "showPhoneNumberWhenRegister": true,
    "showSMSLogin": false,
    "isResetPasswordSupported": true,
    "appleLoginSetting": {
      "appleAccountTeamID": "S9RPAM8224",
      "iOSBundleId": "com.inspireui.mstore.flutter"
    },
    "facebookLoginProtocolScheme": "fb430258564493822",
    "smsLoginAsDefault": false,
    "IsRequiredLogin": false,
    "showFacebook": false,
    "facebookClientToken": ""
  },
  "oneSignalKey": {"enable": false, "appID": ""},
  "onBoardingConfig": {
    "data": [
      {
        "image": "assets/images/fogg-delivery-1.png",
        "title": "Welcome to FluxStore",
        "desc": "Fluxstore is on the way to serve you. "
      },
      {
        "image": "assets/images/fogg-uploading-1.png",
        "title": "Connect Surrounding World",
        "desc":
            "See all things happening around you just by a click in your phone. Fast, conve" +
                "nient and clean."
      },
      {
        "image": "assets/images/fogg-order-completed.png",
        "title": "Let's Get Started",
        "desc": "Waiting no more, let's see what we get!"
      }
    ],
    "autoCropImageByDesign": true,
    "isOnlyShowOnFirstTime": false,
    "version": 1,
    "enableOnBoarding": false,
    "showLanguage": false
  },
  "adConfig": {
    "ads": [],
    "enable": false,
    "googleTestingId": [],
    "adMobAppIdIos": "ca-app-pub-7432665165146018~2664444130",
    "facebookTestingId": "",
    "adMobAppIdAndroid": "ca-app-pub-7432665165146018~2664444130"
  },
  "firebaseDynamicLinkConfig": {
    "iOSAppStoreId": "6478245402",
    "androidPackageName": "com.acwady.app",
    "isEnabled": false,
    "androidAppMinimumVersion": 1,
    "link": "https://acwady.com/",
    "uriPrefix": "https://acwady.page.link",
    "shortDynamicLinkEnable": true,
    "iOSBundleId": "com.acwady.app",
    "iOSAppMinimumVersion": "1.0.1"
  },
  "languagesInfo": [
    {
      "storeViewCode": "ar",
      "code": "ar",
      "name": "Arabic",
      "icon": "assets/images/country/ar.png",
      "text": "العربية"
    },
    {
      "storeViewCode": "",
      "code": "en",
      "name": "English",
      "icon": "assets/images/country/gb.png",
      "text": "English"
    }
  ],
  "paymentConfig": {
    "EnableAddress": false,
    "DefaultCountryISOCode": "KW",
    "EnableAddressLocationNote": false,
    "SmartCOD": {"amountStop": 200, "enabled": false, "extraFee": 10},
    "EnableRefundCancel": false,
    "DefaultStateISOCode": "KW",
    "ShowTransactionDetails": true,
    "GuestCheckout": false,
    "UpdateOrderStatus": false,
    "CheckoutPageSlug": {"en": "checkout"},
    "ShowWebviewCheckoutSuccessScreen": true,
    "excludedPaymentIds": [],
    "EnableReview": false,
    "EnableShipping": false,
    "EnableCreditCard": false,
    "NativeOnePageCheckout": false,
    "EnableCustomerNote": false,
    "EnableOnePageCheckout": false,
    "EnableAlphanumericZipCode": false,
    "allowSearchingAddress": false,
    "RefundPeriod": 7,
    "ShowOrderNotes": false
  },
  "payments": {
    "expresspay_apple_pay": "assets/icons/payment/apple-pay-mark.svg",
    "tap": "assets/icons/payment/tap.png",
    "paystack": "assets/icons/payment/paystack.png",
    "stripe_v2_google_pay": "assets/icons/payment/google-pay-mark.png",
    "ppcp-gateway": "assets/icons/payment/paypal.svg",
    "midtrans": "assets/icons/payment/midtrans.png",
    "xendit_cc": "assets/icons/payment/xendit.png",
    "stripe_v2_apple_pay": "assets/icons/payment/apple-pay-mark.svg",
    "myfatoorah_v2": "assets/icons/payment/myfatoorah.png",
    "thai-promptpay-easy": "assets/icons/payment/prompt-pay.png",
    "stripe": "assets/icons/payment/stripe.svg",
    "razorpay": "assets/icons/payment/razorpay.svg",
    "paypal": "assets/icons/payment/paypal.svg"
  },
  "paypalConfig": {
    "clientId":
        "ASlpjFreiGp3gggRKo6YzXMyGM6-NwndBAQ707k6z3-WkSSMTPDfEFmNmky6dBX00lik8wKdToWiJj" +
            "5w",
    "production": false,
    "paymentMethodId": "paypal",
    "nativeMode": false,
    "secret":
        "ECbFREri7NFj64FI_9WzS6A0Az2DqNLrVokBo0ZBu4enHZKMKOvX45v9Y1NBPKFr6QJv2KaSp5vk5A" +
            "1G",
    "returnUrl": "com.inspireui.fluxstore://paypalpay",
    "enabled": false
  },
  "myFatoorahConfig": {
    "apiToken":
        "K4zuagpI_nQo8wXwlu2sz1sA43BPMU0npg7alySblaa9tg-XAcV35wfRqh7jQvH6o1jYqE8IGaMGLCUYD1NXdNWFc2cqIbS1vu1xJI2ygM8pviMByCRFgGxdubhmy8fp4Bc_9Ud689QsKFfI-b404wvb0oCYcz6UqneimYMX0Sr0UxhvahrZA3oUsp07xmxA7NinVGxE4YnoNQsqxtiJ94MjOEy3wRczhDHdnPxvBpnx6e0Etq9w5j-wiKKmpMGgIkhp7ewJ4bmMrXOSVCmFH6eQXiRWDMFBfJrdZkNsWnXLGFJAXEarxXUKSmwI7YreKIlNrJsBQgzkrP3YFUN6TZbmTzQyuFDR9AJTifsyRhgMQ-6rF99K9FqGqcwykOLp_fz8JKbjAvEi-ejTjRmsT5Mt-Z1jqC1NTk4oG7o3cK8eQYE-XzcNenA151GUlRQ75uB-cWngEnsr903Dn34VHh-_sto8PosoW7RS7BrypCF1fDFiXz6aN3slb1KPoUOCTC-YdAS4gFvmytQpe5mBEr_Ym-l1tF-lqcBwzQhinF4fbumjvY5yMD7_xUzq1DPnyqMeklGq5yT8ciEYHxca2r4Kvo2IgWPK1SuhMKM-4v8pkVtvjBbPlU70NT2V6ABL3l9gUlCnwHLDzEFMI1IddRUllHYWB9m3r3tEXO9LEHnmS08uw0tnfwPg4dBJ_FEwxr2EDg",
    "production": false,
    "paymentMethodId": "myfatoorah_v2",
    "accountCountry": "KW",
    "enabled": true
  },
  "inAppPurchaseConfig": {
    "subscriptionProductIDs": ["com.inspireui.fluxstore.subscription.test"],
    "nonConsumableProductIDs": [],
    "consumableProductIDs": ["com.inspireui.fluxstore.test"],
    "enabled": false
  },
  "defaultCountryShipping": [],
  "afterShip": {
    "api": "e2e9bae8-ee39-46a9-a084-781d0139274f",
    "tracking_url": "https://fluxstore.aftership.com"
  },
  "googleApiKey": {
    "web": "AIzaSyDSNYVC-8DU9BTcyqkeN9c5pgVhwOBAvGg",
    "android": "AIzaSyDSNYVC-8DU9BTcyqkeN9c5pgVhwOBAvGg",
    "ios": "AIzaSyDSNYVC-8DU9BTcyqkeN9c5pgVhwOBAvGg"
  },
  "productDetail": {
    "height": 0.364285090782123,
    "marginTop": 51.396648044692725,
    "safeArea": false,
    "attributeLayout": "normal",
    "buyButtonStyle": "fixedBottom",
    "showVideo": false,
    "showThumbnailAtLeast": 1,
    "layout": "simpleType",
    "borderRadius": 3.0,
    "ShowSelectedImageVariant": true,
    "ForceWhiteBackground": false,
    "AutoSelectFirstAttribute": true,
    "enableReview": true,
    "attributeImagesSize": 50.0,
    "showSku": false,
    "showStockQuantity": true,
    "showProductCategories": false,
    "showProductTags": false,
    "hideInvalidAttributes": false,
    "ShowImageGallery": false,
    "autoPlayGallery": false,
    "allowMultiple": false,
    "showBrand": false,
    "showQuantityInList": false,
    "showAddToCartInSearchResult": true,
    "productListItemHeight": 125.0,
    "limitDayBooking": 14,
    "boxFit": "contain",
    "SliderShowGoBackButton": true,
    "SliderIndicatorType": "number",
    "productMetaDataKey": "",
    "showRelatedProductFromSameStore": true,
    "showRelatedProduct": true,
    "showRecentProduct": false,
    "productImageLayout": "page",
    "expandDescription": false,
    "expandInfors": true,
    "expandCategories": true,
    "expandTags": true,
    "expandReviews": true,
    "expandTaxonomies": true,
    "expandListingMenu": true,
    "expandMap": true,
    "showListCategoriesInTitle": true,
    "showSocialLinks": true
  },
  "blogDetail": {
    "showAuthorInfo": true,
    "showTextAdjustment": true,
    "showRelatedBlog": true,
    "showComment": true,
    "showHeart": true,
    "showSharing": true,
    "enableAudioSupport": false
  },
  "productVariantLayout": {
    "color": "color",
    "size": "box",
    "color-image": "image",
    "height": "option"
  },
  "productAddons": {
    "allowedCustomType": ["png", "pdf", "docx"],
    "allowMultiple": false,
    "allowImageType": false,
    "allowVideoType": false,
    "allowCustomType": false,
    "fileUploadSizeLimit": 5
  },
  "cartDetail": {
    "maxAllowQuantity": 10,
    "minAllowTotalCartValue": 0,
    "style": "style01"
  },
  "productVariantLanguage": {
    "ar": {
      "color": "اللون",
      "size": "بحجم",
      "color-image": "اللون",
      "height": "ارتفاع"
    },
    "vi": {
      "color": "Màu",
      "size": "Kích thước",
      "color-image": "Màu",
      "height": "Chiều Cao"
    },
    "en": {
      "color": "Color",
      "size": "Size",
      "color-image": "Color",
      "height": "Height"
    }
  },
  "excludedCategory": "311",
  "saleOffProduct": {
    "ShowCountDown": true,
    "HideEmptySaleOffLayout": false,
    "Color": "#C7222B"
  },
  "notStrictVisibleVariant": true,
  "configChat": {
    "showOnScreens": [
      "profile",
      "wishlist",
      "products",
      "page",
      "home-search",
      "orders",
      "order-detail",
      "language"
    ],
    "hideOnScreens": [],
    "enableVendorChat": true,
    "EnableSmartChat": true,
    "UseRealtimeChat": false,
    "version": "2"
  },
  "smartChat": [
    {
      "app": "https://wa.me/96598779023",
      "imageData": "https://i.imgur.com/2XrhN48.png",
      "description": "WhatsApp",
      "iconData": "whatsapp"
    },
    {
      "app": "https://telegram.me/acwady",
      "imageData": "https://i.imgur.com/eVmvSpB.png",
      "description": "Telegram",
      "iconData": "facebookMessenger"
    }
  ],
  "adminEmail": "admininspireui@gmail.com",
  "adminName": "InspireUI",
  "deliveryConfig": {
    "appLogo": "assets/images/app_icon_transparent.png",
    "appName": "FluxStore Delivery",
    "dashboardName2": "Delivery",
    "dashboardName1": "FluxStore",
    "enableSystemNotes": false
  },
  "managerConfig": {
    "appLogo": "assets/images/app_icon_transparent.png",
    "appName": "FluxStore Admin",
    "enableDeliveryFeature": false
  },
  "loadingIcon": {"layout": "spinkit", "type": "ring"},
  "splashScreen": {
    "duration": 500,
    "image": "https://trello.com/1/cards/65e827439a0d2760a4fceb49/attachments/667bc2920c292b" +
        "a6f07fe6d2/download/G1.gif",
    "animationName": "ACWADY",
    "backgroundColor": "#0b36ac",
    "paddingBottom": 0,
    "enable": true,
    "paddingRight": 80,
    "boxFit": "contain",
    "paddingTop": 0,
    "type": "fade-in",
    "paddingLeft": 80
  },
  "productCard": {
    "enableRating": true,
    "showCartIcon": true,
    "showCartButtonWithQuantity": false,
    "hideTitle": false,
    "borderRadius": 3,
    "hideStore": true,
    "showCartButton": false,
    "showCartIconColor": false,
    "boxFit": "cover",
    "orderby": "price",
    "hidePrice": false,
    "order": "desc"
  },
  "darkConfig": {"MainColor": "ff0b36ac", "logo": "assets/images/acwady2.png"},
  "colorOverrideConfig": {
    "ratingColor": {
      "primaryLinearProgress": "fff39c12",
      "borderStar": "ff0b36ac",
      "primaryStar": "fff39c12",
      "backgroundLinearProgress": "fff1f2f3"
    },
    "productFilterColor": {
      "backgroundColorOpacity": 1,
      "labelColorOpacity": 1,
      "useAccentColor": false,
      "useBackgroundColor": false,
      "usePrimaryColorLight": false
    },
    "stockColor": {
      "backorder": "ffeaa601",
      "outOfStock": "ffe74c3c",
      "inStock": "ff0b36ac"
    }
  },
  "addressFields": [
    {
      "visible": true,
      "editable": true,
      "defaultValue": "",
      "position": 1,
      "type": "firstName",
      "required": true
    },
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 2,
      "type": "lastName",
      "required": true
    },
    {
      "visible": true,
      "editable": true,
      "defaultValue": "",
      "position": 3,
      "type": "phoneNumber",
      "required": true
    },
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 4,
      "type": "email",
      "required": true
    },
    {"visible": false, "position": 5, "type": "searchAddress"},
    {"visible": false, "position": 6, "type": "selectAddress"},
    {"visible": false, "position": 7, "type": "country"},
    {"visible": false, "position": 8, "type": "state"},
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 9,
      "type": "city",
      "required": true
    },
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 10,
      "type": "apartment",
      "required": false
    },
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 11,
      "type": "block",
      "required": false
    },
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 12,
      "type": "street",
      "required": true
    },
    {
      "visible": false,
      "editable": true,
      "defaultValue": "",
      "position": 13,
      "type": "zipCode",
      "required": true
    }
  ],
  "notificationRequestScreen": {
    "image": "https://trello.com/1/cards/65e827439a0d2760a4fceb49/attachments/667bc7e31e6bea" +
        "c600d51318/download/otifications_yellow.svg",
    "icon": "https://trello.com/1/cards/65e827439a0d2760a4fceb49/attachments/667bc82d3e44f0" +
        "1da27e6fac/download/notification.png"
  },
  "lightConfig": {"MainColor": "ff0b36ac", "logo": "assets/images/acwady.png"}
};
